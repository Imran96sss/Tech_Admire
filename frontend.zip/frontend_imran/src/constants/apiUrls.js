
const API_URLS = {
    SIGNUP: 'http://localhost:9999/api/v1/student/signup',
    LOGIN: 'http://localhost:9999/api/v1/student/login',
    CREATE_APPLICATION: 'http://localhost:9999/api/v1/application/',
    
};
  

export default API_URLS;  